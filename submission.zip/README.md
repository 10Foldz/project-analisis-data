# project-analisis-data
 
## Setup Shell/Terminal
```
mkdir dicoding-bike-sharing
cd dicoding-bike-sharing
pipenv install
pipenv shell
pip install -r requirements.txt
```

## Run dashboard using the streamlit app
```
streamlit run app.py
```
